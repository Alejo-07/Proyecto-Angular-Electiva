export class Facultad {
  Nombre: string;
  Sede: string;
}
