import { Facultad } from "./Facultad";

export class Estudiante {
  Codigo: string;
  Nombre: string;
  Semestre: number;
  Facultad: Facultad;
  Edad: number;
  Email: string;
}
