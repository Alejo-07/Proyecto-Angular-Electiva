import { Facultad } from "./Facultad";

export class Profesor {
  Codigo: string;
  Email: string;
  Nombre: string;
  Edad: number;
  Facultades: Facultad[];
}
