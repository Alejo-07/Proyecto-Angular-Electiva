export * from './Estudiante';
export * from './Facultad';
export * from './Profesor';